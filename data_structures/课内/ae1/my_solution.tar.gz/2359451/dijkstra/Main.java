import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * Dijkstra
 * program to find word ladder with shortest distance for two words in a dictionary
 * distance between elements of the word ladder is the absolute difference in the
 * positions of the alphabet of the non-matching letter
 * <p>
 * for example difference between angel & anger, = ascii(r) - ascii(l)
 */
public class Main {
    /**
     * @param reader: character input channel
     * @return java.util.Set<java.lang.String>
     * @description: readDict, read the contents from a character input channel into Hashset
     */
    public static List<String> readDict(FileReader reader) throws IOException {
        List<String> dictionary = new ArrayList<>();
        char[] buffer = new char[5];
        int readCounts;
        while ((readCounts = reader.read(buffer)) != -1) {
            String word = new String(buffer, 0, readCounts);
            reader.read();// newline 1
            reader.read();// newline 2
            dictionary.add(word);
        }
        return dictionary;
    }

    /**
     * @param dict: pass a List to support the converting
     * @return java.util.Map<java.lang.String, java.lang.Integer>
     * @description: dictMap, get a dictionary mapping from 5-letter word to index in graph
     */
    public static Map<String, Integer> dictMap(List<String> dict) {
        Map<String, Integer> dictionary = new HashMap<>();// mapping words: index
        for (int i = 0; i < dict.size(); i++) {
            dictionary.put(dict.get(i), i);
        }
        return dictionary;
    }

    /**
     * @param dict: dictionary to be printed
     * @return void
     * @description: printDict, print all the elements in the dictionary
     */
    public static void printDict(Set<String> dict) {
        dict.forEach(System.out::println);
    }

    /**
     * @param end: the ending word vertex used to traverse back
     * @return java.util.List<java.lang.String>
     * @description: getLadder, get the path information stored in List
     */
    public static List<String> getLadder(Vertex end) {
        Deque<String> path = new ArrayDeque<>();
        while (end != null) {
            path.addFirst(end.getLetter());
            end = end.getPrev();
        }
        return new ArrayList<>(path);
    }

    /**
     * @param end: ending word vertex stored the cost taken
     * @return int
     * @description: getLadderLength, return the minimum cost/path to convert
     * from starting word to ending word
     */
    public static int getLadderLength(Vertex end) {
        if (end != null) {
            return end.getWeight();
        }
        return -1;
    }

    public static void main(String[] args) throws IOException {
        long start = System.currentTimeMillis();

        String inputFileName = args[0]; // dictionary
        String word1 = args[1]; // first word
        String word2 = args[2]; // second word

        FileReader reader = null;//file exclusive char input channel
        // IO-exception
        try {
            reader = new FileReader(inputFileName);
            //Scanner in = new Scanner(reader);//next(), nextLine()

            // read in the data here, mapping word: index
            List<String> dict = readDict(reader);
            Map<String, Integer> dictMap = dictMap(dict);
            // create graph here
            Graph graph = Graph.createG(dictMap);

            // use the dijkstra algo to find the shortest path
            // all the info is stored in the end word vertex
            Vertex result = graph.Dijkstra(word1, word2, dictMap);

            // do the work here
            // print the ladder length & shortest path
            if (result != null) {
                System.out.printf("[%s->%s] minimum path distance [%d]\n"
                        , word1, word2, getLadderLength(result));
                System.out.println("path with minimum distance:");
                getLadder(result).forEach(System.out::println);
            } else {
                System.out.printf("[%s->%s] no word ladder exists\n"
                        , word1, word2);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                reader.close();
            }
        }

        // end timer and print total time
        long end = System.currentTimeMillis();
        System.out.println("\nElapsed time: " + (end - start) + " milliseconds");
    }

}
