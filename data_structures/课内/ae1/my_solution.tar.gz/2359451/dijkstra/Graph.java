import java.util.*;

/**
 * class to represent an undirected graph using adjacency lists
 */
public class Graph {

    private Vertex[] vertices; // the (array of) vertices
    private int numVertices = 0; // number of vertices, from user input

    /**
     * creates a new instance of Graph with n vertices
     */
    public Graph(int n, Map<String, Integer> dict) {
        numVertices = n;
        vertices = new Vertex[n];
        for (String letter : dict.keySet()) {
            // initialise each vertexes
            vertices[dict.get(letter)] = new Vertex(dict.get(letter), letter);
        }
    }

    public int size() {
        return numVertices;
    }

    public Vertex getVertex(int i) {
        return vertices[i];
    }

    public void setVertex(int i) {
        vertices[i] = new Vertex(i);
    }

    /**
     * visit vertex v, with predecessor index p,
     * during a depth first traversal of the graph
     * <p>
     * visit vertex v & set its relationship between predecessor
     */
    private void Visit(Vertex v, int p) {
        v.setVisited(true);
        v.setPredecessor(p);
        LinkedList<AdjListNode> L = v.getAdjList(); // get the edge list of vertex v
        //iterating each edge, dfs, till no edge found
        for (AdjListNode node : L) {
            int n = node.getVertexIndex();
            if (!vertices[n].getVisited()) {
                Visit(vertices[n], v.getIndex());// visit the adjacent nodes
            }
        }
    }

    /**
     * carry out a depth first search/traversal of the graph
     */
    public void dfs() {
        for (Vertex v : vertices)
            v.setVisited(false);//initialise all the vertex to not visited

        for (Vertex v : vertices)
            if (!v.getVisited())
                Visit(v, -1);//start point - no parent
    }

    /**
     * carry out a breadth first search/traversal of the graph
     * Queue: current vertex's adjacent nodes
     * each turn push the new vertex into Queue, then pop the Q, visit the vertex(if not visited)
     * Push all the adjacent nodes into Queue
     * then repeating...
     */
    public void bfs() {
        //assign each vertex to be unvisited;
        for (Vertex v : vertices) {
            v.setVisited(false);
        }
        //set up an initially empty queue of visited but unprocessed vertices;
        Queue<Vertex> queue = new LinkedList<>();
        for (Vertex v : vertices) {
            if (!v.getVisited()) {
                v.setPredecessor(v.getIndex());
                queue.add(v);
                v.setVisited(true);

                while (!queue.isEmpty()) {
                    // get from the front
                    Vertex front = queue.remove();
                    // visit the adjacent nodes of front vertex
                    LinkedList<AdjListNode> edges = front.getAdjList();
                    for (AdjListNode edge : edges) {
                        if (!vertices[edge.getVertexIndex()].getVisited()) {
                            vertices[edge.getVertexIndex()].setVisited(true);
                            vertices[edge.getVertexIndex()].setPredecessor(front.getIndex());
                            queue.add(vertices[edge.getVertexIndex()]);
                        }
                    }
                }
            }
        }
    }

    public Vertex Dijkstra(String start, String end, Map<String, Integer> dictionary) {

        List<Vertex> ends = new ArrayList<>();// store all the end Vertex (each path)
        //HashSet<String> visited = new HashSet<>();
        Vertex[] vertices_list = this.vertices;

        Vertex starting = vertices_list[dictionary.get(start)]; // starting vertex
        starting.setWeight(0);

        while (true) {
            // each turn pick out the vertex with smallest weight
            int min = Integer.MAX_VALUE;
            int flag = -1;
            for (String each : dictionary.keySet()) {
                Integer minIndex = dictionary.get(each);
                Vertex minVex = vertices_list[minIndex];
                if (!minVex.getVisited() && minVex.getWeight() < min) {
                    min = vertices_list[dictionary.get(each)].getWeight();
                    flag = dictionary.get(each);//index
                }
            }
            if (flag == -1) {
                break;
            }
            Vertex front = vertices_list[flag];
            String currentWord = vertices_list[flag].getLetter();
            front.setVisited(true);
            int currDis = front.getWeight();

            if (currentWord.equals(end)) {
                //found
                ends.add(front);
            }

            //iterating all the words, filtering the 1 step adjacent nodes
            for (String key : dictionary.keySet()) {

                // filter the diff/ k ==1 (takes 1 step to convert)
                int k = 0;
                for (int i = 0; i < key.length(); i++) {
                    if (currentWord.charAt(i) != key.charAt(i)) {
                        k++;
                    }
                    if (k > 1) {
                        break;//takes more steps
                    }
                }

                // update for the adjacent nodes
                // takes 1 step to change to each word
                if (k == 1) {
                    int dis_diff = edgeWeight(key, currentWord);// distance between current new nodes & adjacent nodes
                    Vertex adj = vertices_list[dictionary.get(key)];

                    if (!adj.getVisited() && (currDis + dis_diff) < adj.getWeight()) {
                        adj.setWeight(currDis + dis_diff);
                        adj.setPrev(front);
                    }
                }
            }
            if (ends.size() > 0) break;
        }
        return ends.size()>0 ? ends.get(0) : null;
    }

    public static Graph createG(Map<String, Integer> dictionary) {
        return new Graph(dictionary.size(), dictionary);
    }

    public static int edgeWeight(String s1, String s2) {
        int dis_diff = 0;
        char[] w1 = s1.toCharArray();
        char[] w2 = s2.toCharArray();
        for (int x = 0; x < w1.length; x++) {
            int diff1 = w1[x];
            int diff2 = w2[x];
            dis_diff += Math.abs(diff1 - diff2);
        }
        return dis_diff;
    }

}
