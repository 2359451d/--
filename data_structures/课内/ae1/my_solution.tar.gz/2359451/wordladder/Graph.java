import java.util.*;

/**
 * class to represent an undirected graph using adjacency lists
 */
public class Graph {

    private Vertex[] vertices; // the (array of) vertices
    private int numVertices = 0; // number of vertices, from user input

    // possibly other fields representing properties of the graph

    /**
     * creates a new instance of Graph with n vertices
     */
    public Graph(int n) {
        numVertices = n;
        vertices = new Vertex[n];
        for (int i = 0; i < n; i++)
            vertices[i] = new Vertex(i);// initialise each vertexes
    }

    public int size() {
        return numVertices;
    }

    public Vertex getVertex(int i) {
        return vertices[i];
    }

    public void setVertex(int i) {
        vertices[i] = new Vertex(i);
    }

    /**
     * visit vertex v, with predecessor index p,
     * during a depth first traversal of the graph
     * <p>
     * visit vertex v & set its relationship between predecessor
     */
    private void Visit(Vertex v, int p) {
        v.setVisited(true);
        v.setPredecessor(p);
        LinkedList<AdjListNode> L = v.getAdjList(); // get the edge list of vertex v
        //iterating each edge, dfs, till no edge found
        for (AdjListNode node : L) {
            int n = node.getVertexIndex();
            if (!vertices[n].getVisited()) {
                Visit(vertices[n], v.getIndex());// visit the adjacent nodes
            }
        }
    }

    /**
     * carry out a depth first search/traversal of the graph
     */
    public void dfs() {
        for (Vertex v : vertices)
            v.setVisited(false);//initialise all the vertex to not visited

        for (Vertex v : vertices)
            if (!v.getVisited())
                Visit(v, -1);//start point - no parent
    }

    /**
     * carry out a breadth first search/traversal of the graph
     * psedocode version
     * <p>
     * Queue: current vertex's adjacent nodes
     * each turn push the new vertex into Queue, then pop the Q, visit the vertex(if not visited)
     * Push all the adjacent nodes into Queue
     * then repeating...
     */
    public void bfs() {
        //assign each vertex to be unvisited;
        for (Vertex v : vertices) {
            v.setVisited(false);
        }
        //set up an initially empty queue of visited but unprocessed vertices;
        Queue<Vertex> queue = new LinkedList<>();
        for (Vertex v : vertices) {
            if (!v.getVisited()) {
                v.setPredecessor(v.getIndex());
                queue.add(v);
                v.setVisited(true);

                while (!queue.isEmpty()) {
                    // get from the front
                    Vertex front = queue.remove();
                    // visit the adjacent nodes of front vertex
                    LinkedList<AdjListNode> edges = front.getAdjList();
                    for (AdjListNode edge : edges) {
                        if (!vertices[edge.getVertexIndex()].getVisited()) {
                            vertices[edge.getVertexIndex()].setVisited(true);
                            vertices[edge.getVertexIndex()].setPredecessor(front.getIndex());
                            queue.add(vertices[edge.getVertexIndex()]);
                        }
                    }
                }
            }
        }
    }

    /**
     * @param ladders
     * @return void
     * @description: getLadderInfo print the ladder length & ladder sequence(path) to System.out
     */
    public static void getLadderInfo(String start, String end, List<List<String>> ladders) {
        if (ladders.isEmpty()) {
            System.out.println("no word ladder exists");
            return;
        }
        // return the shortest path
        int min = Integer.MAX_VALUE;
        int index = 0;
        for (List<String> each :
                ladders) {
            if (each.size() < min) {
                min = each.size() - 1;
                index = ladders.indexOf(each);
            }
        }
        System.out.printf("[%s->%s] shortest word ladder of length [%d]\n", start, end, min);
        ladders.get(index).forEach(System.out::println);
    }

    /**
     * @param start start word
     * @param end   end word
     * @param dict  dictionary Set representation
     * @return java.util.List<Vertex>
     * @description: bfsConstruct, using BFS to construct path to
     * find the shortest path to convert between 5-letter words
     */
    public static List<Vertex> bfsConstruct(String start, String end, Set<String> dict) {
        // from the start word to construct
        //set up an initially empty queue of visited but unprocessed vertices;
        Queue<Vertex> queue = new LinkedList<>();
        Set<String> visited = new HashSet<>();// avoids the repeated path
        List<List<String>> result = new ArrayList<>();// store the path
        List<Vertex> ends = new ArrayList<>();// store all the end Vertex (each path)

        Vertex start_w = new Vertex(start, null);// starting word vertex
        start_w.setVisited(true);
        queue.offer(start_w);//starting vertex push to queue

        //start to bfs
        while (!queue.isEmpty()) {
            //iterating all the nodes in the queue
            for (int i = 0; i < queue.size(); i++) {
                Vertex front = queue.remove();// get the front of queue
                String currentWord = front.getLetter();// letter representation of front vertex
                visited.add(currentWord); // current word already visited
                front.setVisited(true);
                // whether current word is end word
                if (currentWord.equals(end)) {
                    ends.add(front);
                }

                //iterating each character & modify to check whether it is in dictionary
                //if in dictionary & not visited, added to the graph
                StringBuilder newWord = new StringBuilder(currentWord);
                for (int j = 0; j < currentWord.length(); j++) {
                    char current_c = currentWord.charAt(j);
                    for (char k = 'a'; k <= 'z'; k++) {
                        // do not do replace for the same char
                        if (k == currentWord.charAt(j)) {
                            continue;
                        }
                        // do the replace
                        newWord.setCharAt(j, k);
                        String tempStr = newWord.toString();
                        // check whether the word in dictionary & not visited yet
                        // if so, added to the relationship
                        if (dict.contains(tempStr) && !visited.contains(tempStr)) {
                            //dict.remove(newWord);
                            queue.add(new Vertex(tempStr, front));
                        }
                    }
                    newWord.setCharAt(j, current_c);//recover to origin
                }
            }
            // no need to check next path
            if (ends.size() > 0) break;
        }
        return ends;
    }

}
