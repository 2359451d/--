
/**
 * class to represent an entry in the adjacency list of a vertex
 * in a graph
 * node in Edge list
 */
public class AdjListNode {

    private int vertexIndex;// vertex index of this node

    // could be other fields, for example representing
    // properties of the edge - weight, capacity, ...
    /* creates a new instance */
    public AdjListNode(int n) {
        vertexIndex = n;
    }

    public int getVertexIndex() {
        return vertexIndex;
    }

    public void setVertexIndex(int n) {
        vertexIndex = n;
    }

}
