import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * program to find word ladder with shortest path (i.e. minimum number edges
 * - find the length of shortest path
 * - find the sequence of shortest path (nodes included in)
 * - or report that there is no ladder
 * - print the execution time, System.currentTimeMillis()
 * Print the results to standard output System.out
 */
public class Main {
    /**
     * @param reader: character input channel
     * @return List<String>
     * @description: dictSet, read the contents from a character input channel into set
     */
    public static Set<String> dictSet(FileReader reader) throws IOException {
        Set<String> dictionary = new HashSet<>();
        char[] buffer = new char[5];
        int readCounts = 0;
        while ((readCounts = reader.read(buffer)) != -1) {
            String word = new String(buffer, 0, readCounts);
            reader.read();// newline 1
            reader.read();// newline 2
            dictionary.add(word);
        }
        return dictionary;
    }

    /**
     * @param dict: dictionary to be printed
     * @return void
     * @description: printDict, print all the elements in the dictionary
     */
    public static void printDict(Set<String> dict) {
        dict.forEach(System.out::println);
    }

    /**
     * @param end ending vertex used to traverse back
     * @return java.util.List<java.lang.String>
     * @description: getLadder, from the end vertex to traverse back along the path (utilising the prev pointer)
     * i.e. traverse reversely
     */
    public static List<String> getLadder(Vertex end) {
        Deque<String> path = new ArrayDeque<>();
        while (end != null) {
            path.addFirst(end.getLetter());
            end = end.prev;
        }
        return new ArrayList<>(path);
    }

    /**
     * @param ladder: the string sequence of ladder path
     * @return the size of ladder
     */
    public static int getLadderLength(List<String> ladder) {
        return ladder.size();
    }

    public static void main(String[] args) throws IOException {

        long start = System.currentTimeMillis();

        String inputFileName = args[0]; // dictionary, word5.txt
        String word1 = args[1]; // first word, start word
        String word2 = args[2]; // second word, end word

        FileReader reader = null;//file exclusive char input channel
        // IO-exception
        try {
            reader = new FileReader(inputFileName);
            //Scanner in = new Scanner(reader);//next(), nextLine()

            // read in the data here
            Set<String> dict = dictSet(reader);

            // create graph here
            /*
             * enumerate all the possible char of each letter position
             * to construct the specific letters, then check the
             * existence in the dictionary
             *
             * use BFS to construct the ladders
             * */
            List<Vertex> ladder = Graph.bfsConstruct(word1, word2, dict);
            // do the work here
            // print the ladder length & shortest path
            if (ladder.size() > 0) {
                System.out.printf("[%s->%s] shortest word ladder of length [%d]\n"
                        , word1, word2, getLadderLength(getLadder(ladder.get(0))));
                System.out.println("shortest word ladder:");
                getLadder(ladder.get(0)).forEach(System.out::println);
            } else {
                System.out.printf("[%s->%s] no word ladder exists\n"
                        , word1, word2);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                reader.close();
            }
        }

        // end timer and print total time
        long end = System.currentTimeMillis();
        System.out.println("\nElapsed time: " + (end - start) + " milliseconds");
    }

}
