import java.util.LinkedList;


/**
 * class to represent a vertex in a graph
 */
public class Vertex {

    private LinkedList<AdjListNode> adjList; // the adjacency list of the vertex
    private int index; // the index of the vertex

    // possibly other fields, for example representing data
    // stored at the node, whether the vertex has been visited
    // in a traversal, its predecessor in such a traversal, etc.
    String letter;

    boolean visited; // whether vertex has been visited in a traversal
    int predecessor; // index of predecessor vertex in a traversal, parent, for better print or finding
    Vertex prev; // for storing the information of predecessor

    /**
     * creates a new instance of Vertex
     */
    public Vertex(int n) {
        adjList = new LinkedList<AdjListNode>();
        index = n;
        visited = false;
    }

    public Vertex(String letter, Vertex prev) {
        this.letter = letter;
        this.prev = prev;
        this.visited = false;
    }

    public Vertex(int index, String letter, Vertex prev) {
        this.index = index;
        this.letter = letter;
        this.prev = prev;
        this.visited = false;
    }

    /**
     * copy constructor: return a copy of vertex v
     */
    public Vertex(Vertex v) {
        adjList = v.getAdjList();
        index = v.getIndex();
        visited = v.getVisited();
    }

    public LinkedList<AdjListNode> getAdjList() {
        return adjList;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int n) {
        index = n;
    }

    public String getLetter() {
        return letter;
    }

    public boolean getVisited() {
        return visited;
    }

    public void setVisited(boolean b) {
        visited = b;
    }

    public int getPredecessor() {
        return predecessor;
    }

    public void setPredecessor(int n) {
        predecessor = n;
    }

    public void addToAdjList(int n) {
        adjList.addLast(new AdjListNode(n));
    }

    public void addToAdjList(AdjListNode v) {
        adjList.addLast(v);
    }

    public int vertexDegree() {
        return adjList.size();
    }
}
